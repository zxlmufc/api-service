#! /bin/bash
date=`date '+%Y%m%d'`
file_path=/home/hadoop/Project/ghs_phase2_api/log/${date}_gunicorn.log


NUM_WORKERS=2
NAME="Static_Table_API"
FLASK_MODULE=main_flask_static
FLASKDIR=/home/hadoop/Project/ghs_phase2_api


source /home/hadoop/anaconda3/bin/activate walmart_env

echo "Starting $NAME as `whoami`"

cd ${FLASKDIR}

/home/hadoop/anaconda3/bin/gunicorn \
--name ${NAME} \
--workers ${NUM_WORKERS} \
--bind 192.168.0.158:8050 \
--worker-class="meinheld.gmeinheld.MeinheldWorker" \
${FLASK_MODULE}:application
 

