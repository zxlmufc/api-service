from configparser import ConfigParser

CONFIG_FILE = 'config.cfg'

CONFIG_SECTION_REDIS = 'REDIS'
CONFIG_SECTION_REDIS_TABLE = 'TABLE_REDIS'
CONFIG_SECTION_SQLSERVER = 'SQL_SERVER'


TEST_REDIS_TABLE_PRFIX = 'static'
TEST_REDIS_TABLE_SUFFIX = ''

REDIS_SENTINEL_HOST = "[('10.88.3.55', 26379), ('10.88.3.56', 26379),('10.88.3.57', 26379)]"
REDIS_PWD = 'meritco'

REDIS_STATIC_UPC = 'weight_upc_recommend'
REDIS_STATIC_USER = 'weight_customer_recommend'
REDIS_STATIC_POP = 'homepage_upc_default_rank'

SQL_SERVER_QA_HOST = '10.88.0.21'
SQL_SERVER_QA_DATABASE = 'GHSMP-SD'
SQL_SERVER_QA_USER = 'ghsmp'
SQL_SERVER_QA_PWD = 'W@lmart321'


def table_name_generator(table_name):
    return '_'.join([TEST_REDIS_TABLE_PRFIX, table_name, TEST_REDIS_TABLE_SUFFIX])


if __name__ == '__main__':
    conf = ConfigParser()
    conf.add_section(CONFIG_SECTION_REDIS)
    conf.set(CONFIG_SECTION_REDIS, 'sentinel_hosts',  REDIS_SENTINEL_HOST)
    conf.set(CONFIG_SECTION_REDIS, 'pwd', REDIS_PWD)

    conf.add_section(CONFIG_SECTION_REDIS_TABLE)
    conf.set(CONFIG_SECTION_REDIS_TABLE, 'static_upc', table_name_generator(REDIS_STATIC_UPC))
    conf.set(CONFIG_SECTION_REDIS_TABLE, 'static_pop', table_name_generator(REDIS_STATIC_POP))
    conf.set(CONFIG_SECTION_REDIS_TABLE, 'static_user', table_name_generator(REDIS_STATIC_USER))

    conf.add_section(CONFIG_SECTION_SQLSERVER)
    conf.set(CONFIG_SECTION_SQLSERVER, 'sql_server_qa_host', SQL_SERVER_QA_HOST)
    conf.set(CONFIG_SECTION_SQLSERVER, 'sql_server_qa_database', SQL_SERVER_QA_DATABASE)
    conf.set(CONFIG_SECTION_SQLSERVER, 'sql_server_qa_user', SQL_SERVER_QA_USER)
    conf.set(CONFIG_SECTION_SQLSERVER, 'sql_server_qa_pwd', SQL_SERVER_QA_PWD)

    with open(CONFIG_FILE, 'w') as cfgfile:
        conf.write(cfgfile)

