# -*- coding:utf-8 -*-


class Constances(object):

    RECOMMEND_NUM_SPLITS = 7

    FINAL_DATA_PATH = '/u1/liurong/Projects/ghs_phase1/final_output'

    UPC_TABLE_SUFFIX = '_Weight_UPC_Recommend.csv'
    HOME_TABLE_SUFFIX = '_Homepage_UPC_Default_Rank.csv'
    CUSTOMER_TABLE_SUFFIX = '_Weight_Customer_Recommend.csv'

    USER_TOP_N = 60

    USER_TABLE_NUM_SPLIT = 20