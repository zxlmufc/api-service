# -*- coding:utf-8 -*-
"""
put 3 static tabel into Redis
@author：Gina LIU
@date: 06 Nov 2018
"""
import configparser
import logging
from conf import generate_conf, Constances
import pandas as pd
from redis.sentinel import Sentinel
import sys


class RedisObject(object):
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s')
    config = configparser.ConfigParser()
    config.read("/home/hadoop/Project/ghs_phase2_api/conf/" + generate_conf.CONFIG_FILE, encoding='utf-8')

    __SENTINEL_HOSTS = config.get("REDIS", "sentinel_hosts")
    __PASSWORD = config.get("REDIS", 'pwd')

    table_static_user = config.get('TABLE_REDIS', 'static_user')
    table_static_upc = config.get('TABLE_REDIS', 'static_upc')
    table_static_pop = config.get('TABLE_REDIS', 'static_pop')

    def __init__(self):
        sentinel = Sentinel(eval(self.__SENTINEL_HOSTS), socket_timeout=0.5)
#        self.master = sentinel.master_for('mymaster', socket_timeout=0.5, password=self.__PASSWORD, decode_responses=True)
        self.master = sentinel.master_for('mymaster', socket_timeout=0.5, decode_responses=True)

    def rhset(self, file_path, field_name, value_name, redis_key):
        '''
        redis hash set function
        :param file_path: input data source
        :param field_name: input data (df) 's colusentinelmn name for hash field, such as 'Phone_Number', 'UPC'
        :param value_name: input data (df)'s column name for hash value, such as 'UPC', 'Recommend_UPC'
        :param redis_key: redis key name
        :return:
        '''
        df = pd.read_csv(file_path, encoding='utf-8')
        df[value_name] = df[value_name].astype(str)
        split = Constances.USER_TABLE_NUM_SPLIT if redis_key == self.table_static_user else 1
        size_per_split = int(df.shape[0]/split)
        logging.info("Start hset redis table {0}, with table shape {1}, will split {2} times".format(redis_key, df.shape, split))
        for i in range(split):
            input_df = df[i*size_per_split :(i+1)*size_per_split]
            p = self.master.pipeline()
            for k, v in input_df.groupby(field_name):
                p.hset(redis_key, k, v[value_name].tolist())
            p.execute()
            logging.info("Finish hset redis table {0}, with table shape {1}".format(redis_key, input_df.shape))

    def rrpush(self, file_path, df_col_name, redis_key):
        '''
        redis list set function
        :param file_path: input data source
        :param df_col_name: input data (df) 's column name for redis list value
        :param redis_key: redis list key name
        :return:
        '''
        df = pd.read_csv(file_path, encoding='utf-8')
        logging.info("Start pushing popular item into {0}, with table shape {1}".format(redis_key, df.shape))
        p = self.master.pipeline()
        for index, row in df.iterrows():
            p.rpush(redis_key, row[df_col_name])
        p.execute()
        logging.info("Finish push popular item into {0}".format(redis_key))


if __name__ == '__main__':
    ro = RedisObject()
    upc_file = "/home/hadoop/Project/ghs_phase2_api/data/upc_sample.csv"
    pop_file = "/home/hadoop/Project/ghs_phase2_api/data/home_sample.csv"
    user_file = "/home/hadoop/Project/ghs_phase2_api/data/user_sample.csv"

    # Weight_UPC_Recommend - redis hash
    ro.rhset(upc_file, field_name='UPC', value_name='Recommend_UPC', redis_key=ro.table_static_upc)
    # Homepage_UPC_Default_Rank - redis list
    ro.rrpush(pop_file, df_col_name='UPC', redis_key=ro.table_static_pop)
    # Weight_Customer_Recommend - redis hash
    ro.rhset(user_file, field_name='Phone_Number', value_name='UPC', redis_key=ro.table_static_user)
