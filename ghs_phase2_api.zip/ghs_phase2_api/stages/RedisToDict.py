# -*- coding:utf-8 -*-
"""
input recommendationId:
 oB4nYjhJHQVaD0PL7qs0W1kL-_ls~13000000000~homepage_cart~shop1~100001,100002~1539157512000~12135
openid~user~page~storeId~items~timestamp~randomint
@author: GinaLIU
@date:07 Nov 2018
"""

import configparser
from conf import generate_conf, Constances
from redis.sentinel import Sentinel
import pandas as pd
import numpy as np

class RecommendIdFactoryStageOneStatic(object):
    SEPERATOR = '~'
    TOP_N = Constances.USER_TOP_N
    
    upc_file = "/home/hadoop/Project/ghs_phase2_api/data/upc_sample.csv"
    home_file = "/home/hadoop/Project/ghs_phase2_api/data/home_sample.csv"
    user_file = "/home/hadoop/Project/ghs_phase2_api/data/user_sample.csv"
     

    def __init__(self, recommendation_id):
        its = recommendation_id.split(self.SEPERATOR)
        self.openid, self.user, self.page, self.storeId, self.items = its[0], its[1], its[2], its[3], its[4]
        self.code = 0 if len(its) == Constances.RECOMMEND_NUM_SPLITS else 2
        self.upc_dict, self.home_list, self.user_dict = self.get_data_dict()
#        print("self.user is {}".format(self.user))
#        print("self.user_dict is {}".format(self.upc_dict))        

    def get_data_dict(self, upc_file_path=upc_file, home_file_path=home_file, user_file_path=user_file):
        upc_dict = self.generate_dict_from_file(upc_file_path, 0, 2)
        home_list = self.generate_list_from_file(home_file_path, 0)
        user_dict = self.generate_dict_from_file(user_file_path, 0, 1)
        return upc_dict, home_list, user_dict
       
    @staticmethod 
    def generate_dict_from_file(file_path, key_index, value_index):
        res_dict = {}
        with open(file_path,'r') as f:
            for line in f:
                its = line.strip().split(',')
                k = its[key_index]
                v = str(its[value_index])
                res_dict.setdefault(k,[]).append(v)
        return res_dict

    @staticmethod
    def generate_list_from_file(file_path, index):
        res_set = list()
        with open(file_path,'r') as f:
            for line in f:
                its = line.strip().split(',')
                element = str(its[index])
                res_set.append(element)
        return res_set
    

    def get_homepage_response(self):
        '''
        in "home page" ,return user's preference or return popular items(by default)
        :return: recommended items
        '''
#        res = self.master.hget(self.table_static_user, self.user)
        res = self.user_dict[self.user] if self.user in self.user_dict else None
        return self.__add_popular_items(res)

    def get_itempage_response(self):
        '''
        in "item page", return upc' similar upcs
        :return: recommended items
        '''
#        res = self.master.hget(self.table_static_upc, self.items)
        res = self.upc_dict[self.items] if self.items in self.upc_dict else None
        return self.__add_popular_items(res)

    def get_homepage_cart_response(self):
        return self.get_homepage_response()

    def get_homepage_order_response(self):
        pass

    def __add_popular_items(self, res):
        res = res if res else []
        if len(res) < self.TOP_N:
#            pop = self.master.lrange(self.table_static_pop, 0, self.TOP_N)
            pop = self.home_list[:self.TOP_N]
            res += [x for x in pop if x not in res]
        return res[:self.TOP_N]

    def response(self):
        function_dict = {'homepage': self.get_homepage_response(),
                         'itempage': self.get_itempage_response(),
                         # 'homepage_order': self.get_homepage_order_response(),
                         'homepage_cart': self.get_homepage_cart_response()}
        return function_dict[self.page]


if __name__ == '__main__':
#    rc = 'oB4nYjhJHQVaD0PL7qs0W1kL-_ls~18817333137~homepage~shop1~100001,100002~1539157512000~12135'
    rc = 'oB4nYjhJHQVaD0PL7qs0W1kL-_ls~4524376681~homepage~shop1~100001,100002~1539157512000~12135'
    rcf = RecommendIdFactoryStageOneStatic(rc)
    print (rcf.response())
