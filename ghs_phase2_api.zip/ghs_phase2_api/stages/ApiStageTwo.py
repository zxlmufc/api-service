# -*- coding:utf-8 -*-
"""
input recommendationId:
 oB4nYjhJHQVaD0PL7qs0W1kL-_ls~13000000000~homepage_cart~shop1~100001,100002~1539157512000~12135
openid~user~page~storeId~items~timestamp~randomint
@author: GinaLIU
@date:07 Nov 2018
"""

import configparser
from conf import generate_conf, Constances
from redis.sentinel import Sentinel


class RecommendIdFactoryStageOne(object):
    SEPERATOR = '~'
    TOP_N = Constances.USER_TOP_N

    config = configparser.ConfigParser()
    config.read("/home/hadoop/Project/ghs_phase2_api/conf/" + generate_conf.CONFIG_FILE, encoding='utf-8')

    __SENTINEL_HOSTS = config.get("REDIS", "sentinel_hosts")
    __PASSWORD = config.get("REDIS", 'pwd')

    table_static_user = config.get('TABLE_REDIS', 'static_user')
    table_static_upc = config.get('TABLE_REDIS', 'static_upc')
    table_static_pop = config.get('TABLE_REDIS', 'static_pop')

    def __init__(self, recommendation_id):
        its = recommendation_id.split(self.SEPERATOR)
        self.openid, self.user, self.page, self.storeId, self.items = its[0], its[1], its[2], its[3], its[4]
        sentinel = Sentinel(eval(self.__SENTINEL_HOSTS), socket_timeout=0.5)
    #    self.master = sentinel.master_for('mymaster', socket_timeout=0.5, password=self.__PASSWORD, decode_responses=True)
        self.master = sentinel.master_for('mymaster', socket_timeout=0.5, decode_responses=True)
        self.code = 0 if len(its) == Constances.RECOMMEND_NUM_SPLITS else 2

    def get_homepage_response(self):
        '''
        in "home page" ,return user's preference or return popular items(by default)
        :return: recommended items
        '''
        res = self.master.hget(self.table_static_user, self.user)
        print('homepage')
        print(res)
        return self.__add_popular_items(res)

    def get_itempage_response(self):
        '''
        in "item page", return upc' similar upcs
        :return: recommended items
        '''
        res = self.master.hget(self.table_static_upc, self.items)
        return self.__add_popular_items(res)

    def get_homepage_cart_response(self):
        return self.get_homepage_response()

    def get_homepage_order_response(self):
        pass

    def __add_popular_items(self, res):
        res = eval(res) if res else []
        if len(res) < self.TOP_N:
            pop = self.master.lrange(self.table_static_pop, 0, self.TOP_N)
            res += [x for x in pop if x not in res]
        return res[:self.TOP_N]

    def response(self):
        function_dict = {'homepage': self.get_homepage_response(),
                         'itempage': self.get_itempage_response(),
                         # 'homepage_order': self.get_homepage_order_response(),
                         'homepage_cart': self.get_homepage_cart_response()}
        return function_dict[self.page]


if __name__ == '__main__':
    rc = 'oB4nYjhJHQVaD0PL7qs0W1kL-_ls~18817333137~homepage~shop1~100001,100002~1539157512000~12135'
    rcf = RecommendIdFactoryStageOne(rc)
    print (rcf.response())
