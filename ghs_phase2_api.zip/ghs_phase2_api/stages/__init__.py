from .ApiStageTwo import RecommendIdFactoryStageOne
from .RedisToDict import RecommendIdFactoryStageOneStatic

__all__ = ['RecommendIdFactoryStageOne', 'RecommendIdFactoryStageOneStatic']
