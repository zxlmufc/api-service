# -*- coding:utf-8 -*-
"""
main entrance of API server
input example:
/rt/v1/?rc=oB4nYjhJHQVaD0PL7qs0W1kL-_ls~13000000000~homepage_cart~shop1~100001,100002~1539157512000~12135&rid=3293F7F434A6A92516AE354634419621

@author: GinaLIU
@date: 07 Nov 2018
"""


from flask import Flask, request,Response
import requests
import json
import hashlib
import time
from stages import RecommendIdFactoryStageOneStatic
from confluent_kafka import Producer

def delivery_report(err, msg):
    """ Called once for each message produced to indicate delivery result.
        Triggered by poll() or flush(). """
    if err is not None:
        logging.warning('Message {} delivery failed: {}'.format(msg, err))

p = Producer({'bootstrap.servers': '192.168.0.152:9092'})

application = Flask(__name__)

recom_kafka_topic = "topicRecRes-1"

def get_time_stamp():
    ct = time.time()
    local_time = time.localtime(ct)
    data_head = time.strftime("%Y%m%d%H%M%S", local_time)
    data_secs = (ct - int(ct)) * 1000
    time_stamp = "%s%03d" % (data_head, data_secs)
    return time_stamp

# filter vicious IPs
@application.before_request
def before_request():
    pass


@application.route('/')
def index():
    return "Hello New World"


@application.errorhandler(404)
def not_found(e):
    return 'URL NOT FOUND' + str(e)


@application.route('/rt/v1/', methods=['GET', 'POST'])
def rt_v1():
    rc = request.args.get('rc')
    rid = request.args.get('rid')
    if check_upper_md5(rc, rid):
        rcf = RecommendIdFactoryStageOneStatic(rc)
        if rcf.code == 2:
            resp = {'code': 2, 'message': 'failure', 'result': 'Null'}
        else:
            resp = {'code': 0, 'message':'success'}
            resp['result'] = rcf.response()
    else:
        resp = {'code': 1, 'message': 'failure', 'result': 'Null'}

    curtime = get_time_stamp()
    recom_type='static'
    recom_kafka_value = '|'.join([curtime, rid,recom_type, str(resp['result'])])

    try:
        p.produce(recom_kafka_topic, recom_kafka_value, callback=delivery_report)
        p.poll(0)
    except BufferError:
        logging.warning("Buffer full, waiting for free space on the queue")
        p.poll(10)  # putting the poll() first to block until there is queue space available. This blocks for 10 seconds
        p.producer(recom_kafka_topic, recom_kafka_value, callback=delivery_report)
    except IOError:
        logging.warning("IO error")
    except Exception as e:
        logging.warning("unexpected error:" + str(e))

    return Response(json.dumps(resp), mimetype='application/json')


def md5(u):
    m = hashlib.md5()
    m.update(u.encode('utf-8'))
    return m.hexdigest()


def check_upper_md5(a, md5_a):
    return True if md5(a).upper() == md5_a else False


if __name__ == '__main__':
    application.run(port='8040', threaded=True)
